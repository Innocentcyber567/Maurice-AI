import React from 'react';

const PredictionPanel = () => {
  const mockPredictions = [
    { market: 'Volatility 75', signal: 'Rise', confidence: 83, entry: '12:31:30' },
    { market: 'Boom 1000', signal: 'Fall', confidence: 75, entry: '12:32:10' }
  ];

  return (
    <div>
      <h2>Market Predictions</h2>
      <ul>
        {mockPredictions.map((p, i) => (
          <li key={i}>
            {p.market}: {p.signal} — Confidence: {p.confidence}%, Entry: {p.entry}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PredictionPanel;