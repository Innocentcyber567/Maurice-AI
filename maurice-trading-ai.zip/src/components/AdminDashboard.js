import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h3>Admin Dashboard</h3>
      <button>Upload Bot from File</button>
      <button>Build New Bot</button>
      <button>Approve Uploaded Bots</button>
    </div>
  );
};

export default AdminDashboard;