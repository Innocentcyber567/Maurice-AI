import React, { useState } from 'react';
import PredictionPanel from './components/PredictionPanel';
import AdminDashboard from './components/AdminDashboard';

function App() {
  const [isAdmin, setIsAdmin] = useState(true); // set true for demo

  return (
    <div>
      <h1>Maurice Trading AI</h1>
      <PredictionPanel />
      {isAdmin && <AdminDashboard />}
    </div>
  );
}

export default App;